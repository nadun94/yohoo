package com.verbosetech.yoohoo.utils;

import android.support.v4.content.FileProvider;

/**
 * Created by a_man on 5/15/2017.
 */

public class MyFileProvider extends FileProvider {
}
